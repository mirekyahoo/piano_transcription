# Prediction interface for Cog ⚙️
# Reference: https://github.com/replicate/cog/blob/main/docs/python.md

import os
import sys
from pathlib import Path

import cog
import librosa
import torch

from synthviz import create_video

# Use the patched local bytedance/piano_transcription repo,
# not the external piano_transcription_inference package.
REPO_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO_ROOT / "pytorch"))
sys.path.insert(0, str(REPO_ROOT / "utils"))

import config
from inference import PianoTranscription


class Predictor(cog.Predictor):
    transcriptor: PianoTranscription

    def setup(self):
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.transcriptor = PianoTranscription(
            model_type="Note_pedal",
            checkpoint_path=str(REPO_ROOT / "model.pth"),
            segment_samples=config.sample_rate * 10,
            device=device,
            post_processor_type="regression",
        )

    @cog.input("audio_input", type=Path, help="Input audio file")
    def predict(self, audio_input):
        midi_intermediate_filename = str(REPO_ROOT / "transcription.mid")
        video_filename = str(REPO_ROOT / "output.mp4")

        audio, _ = librosa.core.load(str(audio_input), sr=config.sample_rate, mono=True)

        # Transcribe audio
        self.transcriptor.transcribe(audio, midi_intermediate_filename)

        # Visualization output option
        create_video(
            input_midi=midi_intermediate_filename,
            video_filename=video_filename,
        )

        print(
            f"Created video of size {os.path.getsize(video_filename)} bytes at path {video_filename}"
        )

        # Return path to video
        return Path(video_filename)
